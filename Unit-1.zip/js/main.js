// Add all scripts to the JS folder

/*Addison Atkin 2024 */


var mydiv = document.getElementById("mydiv");
mydiv.addEventListener("click", function(){
    alert("Hello World!");
});
