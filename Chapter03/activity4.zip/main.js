// Add all scripts to the JS folder

/*Addison Atkin 2024 */


//initialize function called when the script loads
function initialize(){
    cities();
};

//function to create a table with cities and their populations
function cities(){
    //define two arrays for cities and population
    var cityPop = [
    { 
        city: 'Madison',
        population: 233209
    },
    {
        city: 'Milwaukee',
        population: 594833
    },
    {
        city: 'Green Bay',
        population: 104057
    },
    {
        city: 'Superior',
        population: 27244
    }]


    //create the table element
    var table = document.createElement("table");

    //create a header row
    var headerRow = document.createElement("tr");

    //add the "City" and "Population" columns to the header row
    headerRow.insertAdjacentHTML("beforeend","<th>City</th><th>Population</th>")

    //add the row to the table
    table.appendChild(headerRow);

    //loop to add a new row for each city
    for (var i = 0; i < cityPop.length; i++){
        //assign longer html strings to a variable
        var rowHtml = "<tr><td>" + cityPop[i].city + "</td><td>" + cityPop[i].population + "</td></tr>";
        //add the row's html string to the table
        table.insertAdjacentHTML('beforeend',rowHtml);
    }

    document.querySelector("#mydiv").appendChild(table);
}

// //call the initialize function when the DOM has loaded
// document.addEventListener('DOMContentLoaded',initialize)





//debug_ajax.js code


//creates function that will be used as a callback after data is fetched and processed
function debugCallback(response){
    //select the element with the ID 'mydiv' and add a stringified version of the response data to the end of its content
    //display the fetched geojson data on the webpage
	document.querySelector("#mydiv").insertAdjacentHTML('beforeend', '<br>GeoJSON data:<br>' + JSON.stringify(response))
};

//creates function to fethc data from geojson file
function debugAjax(){
	
    //use fetch() to fetch file
	fetch("MegaCities.geojson")
		.then(response => response.json()) //parses text as json
        .then(data => {
			debugCallback(data);
		})
        //prevent error by catching it
        .catch(error => console.error('Error fetching data:', error));

};

//call functions
document.addEventListener('DOMContentLoaded', function(){
    initialize();
    debugAjax();
});
